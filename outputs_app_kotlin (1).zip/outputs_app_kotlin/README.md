# Outputs — Kotlin / Jetpack Compose Scaffold

A native Android rewrite of the same UI scaffold as the Flutter version — **not** the full
production system from the PRD (that's a multi-month backend + verification + moderation build).
This gets you a real, running app shell with in-memory mock data, ready to wire a backend into.

## What's included

- Onboarding: welcome → DOB gate (blocks under-18, UI-only) → citizenship → privacy mode →
  interests → home
- Home feed with category filter chips, post cards, save / not-interested
- Reading Mode post screen: adjustable text size, comments
- Mystery / Investigation screen: Overview, Timeline, Evidence, Theories tabs, submit a theory
- Create Output flow: pick type, write, choose identity mode, publish into the in-memory feed
- Explore/search, Groups list, Inbox (Messages/Requests tabs), Profile (stats, saved, theme
  toggle)
- Single-Activity architecture using Jetpack Navigation Compose + one `AppViewModel`
- `app/google-services.json` is already in place for when you wire up Firebase

## Project layout

```
app/src/main/java/com/cafedate/app/
  MainActivity.kt
  navigation/            # Routes.kt, NavGraph.kt
  data/                  # Models.kt, MockData.kt
  state/                 # AppViewModel.kt — all app state lives here
  ui/theme/               # Color.kt, Theme.kt
  ui/components/          # PostCard, CategoryChip
  ui/screens/
    onboarding/  home/  explore/  create/  groups/  inbox/  profile/  post/  mystery/
```

## Building an APK via GitHub Actions (what you asked for)

`.github/workflows/build-apk.yml` builds a debug APK on every push to `main` and on
`workflow_dispatch`, then uploads it as a workflow artifact (Actions tab → the run → Artifacts →
`outputs-debug-apk`).

**Important:** this project does **not** include a Gradle wrapper (`gradlew` / `gradle-wrapper.jar`),
because that jar is a binary file the sandbox this was built in couldn't generate without network
access. The workflow installs Gradle directly instead of calling `./gradlew`, so it works as-is —
you don't need to add anything for CI to succeed.

If you'd rather have a wrapper (recommended for local dev, so `./gradlew` works on your machine
too):
```bash
# once you have Gradle installed locally
gradle wrapper --gradle-version 8.7
git add gradlew gradlew.bat gradle/
```
then switch the build step in the workflow from `gradle assembleDebug` to `./gradlew assembleDebug`.

## Running it locally

Open the project root in Android Studio (Koala/2024.1+) and let it sync, or from the command
line with Gradle installed:

```bash
gradle assembleDebug
```

The APK lands at `app/build/outputs/apk/debug/app-debug.apk`.

No app icon resources are included (no `mipmap/ic_launcher`), so Android uses the system default
icon — add your own launcher icons in `app/src/main/res/mipmap-*` whenever you're ready.

## What's not included — still needs real engineering

1. **Age/identity verification.** The DOB screen only blocks locally; it's not a real eligibility
   check. Wire a licensed verification provider into `AppViewModel.completeEligibilityCheck()`.
2. **Backend.** Everything lives in `AppViewModel`'s in-memory lists. Firebase dependencies are
   commented out in `app/build.gradle.kts` and the root `build.gradle.kts` — uncomment them, and
   the `google-services.json` is already in place, once you're ready to wire Firestore/Auth/Storage
   (or swap in Supabase, etc.).
3. **Moderation & trust/safety**, **real-time chat / voice / video**, **reputation, notifications,
   case archive, AI-assisted evidence tools** — all out of scope for this scaffold, same as noted
   in the PRD's Phase 2/3.

## Suggested next step

Pick a backend, uncomment the Firebase dependencies (or add Supabase's Kotlin client), and replace
`buildMockPosts()` / the in-memory lists in `AppViewModel` with real reads and writes — the UI
layer is already shaped to consume that data.
