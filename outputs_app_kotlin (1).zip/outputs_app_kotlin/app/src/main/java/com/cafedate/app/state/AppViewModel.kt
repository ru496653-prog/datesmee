package com.cafedate.app.state

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.toMutableStateList
import androidx.lifecycle.ViewModel
import com.cafedate.app.data.AppUser
import com.cafedate.app.data.Comment
import com.cafedate.app.data.OutputPost
import com.cafedate.app.data.PrivacyMode
import com.cafedate.app.data.Theory
import com.cafedate.app.data.buildMockPosts
import java.time.LocalDate
import java.time.Period

class AppViewModel : ViewModel() {

    // --- Theme ---
    var isDarkTheme = mutableStateOf(true)
        private set

    fun toggleTheme() {
        isDarkTheme.value = !isDarkTheme.value
    }

    // --- Onboarding / identity (local-only placeholder, no real verification) ---
    var dateOfBirth = mutableStateOf<LocalDate?>(null)
        private set
    var citizenshipCountry = mutableStateOf<String?>(null)
        private set
    var ageVerified = mutableStateOf(false)
        private set
    var privacyMode = mutableStateOf(PrivacyMode.PSEUDONYM)
        private set
    var selectedInterests: SnapshotStateList<String> = mutableListOf<String>().toMutableStateList()
        private set

    val isAdult: Boolean
        get() {
            val dob = dateOfBirth.value ?: return false
            return Period.between(dob, LocalDate.now()).years >= 18
        }

    fun setDateOfBirth(dob: LocalDate) {
        dateOfBirth.value = dob
    }

    fun setCitizenship(country: String) {
        citizenshipCountry.value = country
    }

    fun completeEligibilityCheck() {
        // Placeholder: a real build must call a verification provider here
        // and only set this true on a genuine eligibility result.
        ageVerified.value = isAdult
    }

    fun setPrivacyMode(mode: PrivacyMode) {
        privacyMode.value = mode
    }

    fun toggleInterest(interest: String) {
        if (selectedInterests.contains(interest)) {
            selectedInterests.remove(interest)
        } else {
            selectedInterests.add(interest)
        }
    }

    // --- Current user ---
    var currentUser = mutableStateOf(AppUser(id = "local-user", displayName = "ShadowWriter"))
        private set

    // --- Content ---
    val posts: SnapshotStateList<OutputPost> = buildMockPosts().toMutableStateList()
    val savedPostIds: SnapshotStateList<String> = mutableListOf<String>().toMutableStateList()
    val notInterestedIds: SnapshotStateList<String> = mutableListOf<String>().toMutableStateList()

    val visiblePosts: List<OutputPost>
        get() = posts.filter { it.id !in notInterestedIds }

    fun toggleSave(postId: String) {
        if (savedPostIds.contains(postId)) savedPostIds.remove(postId) else savedPostIds.add(postId)
    }

    fun markNotInterested(postId: String) {
        notInterestedIds.add(postId)
    }

    fun addPost(post: OutputPost) {
        posts.add(0, post)
    }

    fun addComment(postId: String, comment: Comment) {
        val index = posts.indexOfFirst { it.id == postId }
        if (index == -1) return
        val post = posts[index]
        post.comments.add(0, comment)
        post.commentCount++
        posts[index] = post // re-notify SnapshotStateList observers
    }

    fun addTheory(postId: String, theory: Theory) {
        val index = posts.indexOfFirst { it.id == postId }
        if (index == -1) return
        val post = posts[index]
        post.theories.add(0, theory)
        posts[index] = post // re-notify SnapshotStateList observers
    }
}
