package com.cafedate.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.cafedate.app.state.AppViewModel
import com.cafedate.app.ui.screens.create.CreateOutputScreen
import com.cafedate.app.ui.screens.home.HomeScreen
import com.cafedate.app.ui.screens.mystery.MysteryDetailScreen
import com.cafedate.app.ui.screens.onboarding.AgeGateScreen
import com.cafedate.app.ui.screens.onboarding.CitizenshipScreen
import com.cafedate.app.ui.screens.onboarding.InterestsScreen
import com.cafedate.app.ui.screens.onboarding.PrivacyModeScreen
import com.cafedate.app.ui.screens.onboarding.WelcomeScreen
import com.cafedate.app.ui.screens.post.PostDetailScreen

@Composable
fun OutputsNavGraph(viewModel: AppViewModel) {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.WELCOME) {
        composable(Routes.WELCOME) {
            WelcomeScreen(onGetStarted = { navController.navigate(Routes.AGE_GATE) })
        }
        composable(Routes.AGE_GATE) {
            AgeGateScreen(viewModel = viewModel, onContinue = { navController.navigate(Routes.CITIZENSHIP) })
        }
        composable(Routes.CITIZENSHIP) {
            CitizenshipScreen(viewModel = viewModel, onContinue = { navController.navigate(Routes.PRIVACY_MODE) })
        }
        composable(Routes.PRIVACY_MODE) {
            PrivacyModeScreen(viewModel = viewModel, onContinue = { navController.navigate(Routes.INTERESTS) })
        }
        composable(Routes.INTERESTS) {
            InterestsScreen(
                viewModel = viewModel,
                onFinish = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.WELCOME) { inclusive = true }
                    }
                },
            )
        }
        composable(Routes.HOME) {
            HomeScreen(
                viewModel = viewModel,
                onOpenPost = { postId -> navController.navigate(Routes.postDetail(postId)) },
                onOpenMystery = { postId -> navController.navigate(Routes.mysteryDetail(postId)) },
                onCreate = { navController.navigate(Routes.CREATE) },
            )
        }
        composable(Routes.CREATE) {
            CreateOutputScreen(viewModel = viewModel, onDone = { navController.popBackStack() })
        }
        composable(
            Routes.POST_DETAIL,
            arguments = listOf(navArgument("postId") { type = NavType.StringType }),
        ) { backStackEntry ->
            val postId = backStackEntry.arguments?.getString("postId")
            val post = viewModel.posts.firstOrNull { it.id == postId }
            if (post != null) {
                PostDetailScreen(post = post, viewModel = viewModel, onBack = { navController.popBackStack() })
            }
        }
        composable(
            Routes.MYSTERY_DETAIL,
            arguments = listOf(navArgument("postId") { type = NavType.StringType }),
        ) { backStackEntry ->
            val postId = backStackEntry.arguments?.getString("postId")
            val post = viewModel.posts.firstOrNull { it.id == postId }
            if (post != null) {
                MysteryDetailScreen(post = post, viewModel = viewModel, onBack = { navController.popBackStack() })
            }
        }
    }
}
