package com.cafedate.app.ui.screens.onboarding

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cafedate.app.data.PrivacyMode
import com.cafedate.app.state.AppViewModel
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.weight

private data class PrivacyOption(val mode: PrivacyMode, val title: String, val subtitle: String)

private val options = listOf(
    PrivacyOption(PrivacyMode.REAL_PROFILE, "My profile", "Username, photo, and bio are visible."),
    PrivacyOption(PrivacyMode.PSEUDONYM, "Pseudonym", "Post under a chosen name, e.g. ShadowWriter."),
    PrivacyOption(PrivacyMode.ANONYMOUS_NUMBER, "Anonymous number", "Appear as Anonymous #4827."),
    PrivacyOption(PrivacyMode.FULLY_ANONYMOUS, "Completely anonymous", "Just \"Anonymous\" — nothing else shown."),
)

@Composable
fun PrivacyModeScreen(viewModel: AppViewModel, onContinue: () -> Unit) {
    val current by viewModel.privacyMode

    Scaffold(topBar = { TopAppBar(title = { Text("How do you want to appear?") }) }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
        ) {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(options) { option ->
                    val selected = current == option.mode
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        onClick = { viewModel.setPrivacyMode(option.mode) },
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = selected, onClick = { viewModel.setPrivacyMode(option.mode) })
                            Column(modifier = Modifier.weight(1f)) {
                                Text(option.title, fontWeight = FontWeight.SemiBold)
                                Text(
                                    option.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                )
                            }
                        }
                    }
                }
            }
            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) {
                Text("Continue", modifier = Modifier.padding(vertical = 6.dp))
            }
        }
    }
}
