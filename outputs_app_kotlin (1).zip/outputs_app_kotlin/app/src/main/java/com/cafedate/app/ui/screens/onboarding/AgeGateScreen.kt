package com.cafedate.app.ui.screens.onboarding

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cafedate.app.state.AppViewModel
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

/**
 * Collects a date of birth and blocks progress for anyone under 18.
 *
 * NOTE: this is a UI-only gate. A real launch needs a genuine eligibility
 * check via a verification provider — do not treat this screen alone as
 * sufficient age assurance.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun AgeGateScreen(viewModel: AppViewModel, onContinue: () -> Unit) {
    var showPicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val dob by viewModel.dateOfBirth

    if (showPicker) {
        val state = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let {
                        val date = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()
                        viewModel.setDateOfBirth(date)
                        error = null
                    }
                    showPicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Cancel") } },
        ) {
            DatePicker(state = state)
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("When were you born?") }) }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
        ) {
            Text(
                "Outputs is an 18+ platform. Your date of birth stays private and is never shown on your profile.",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            )
            Spacer(Modifier.height(24.dp))
            OutlinedButton(onClick = { showPicker = true }) {
                Text(dob?.format(DateTimeFormatter.ISO_LOCAL_DATE) ?: "Select date of birth")
            }
            if (error != null) {
                Spacer(Modifier.height(12.dp))
                Text(error!!, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.weight(1f))
            Button(
                onClick = {
                    if (dob == null) {
                        error = "Please select your date of birth."
                        return@Button
                    }
                    if (!viewModel.isAdult) {
                        error = "Outputs is available only to users aged 18 and above."
                        return@Button
                    }
                    onContinue()
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("Continue", modifier = Modifier.padding(vertical = 6.dp))
            }
        }
    }
}
