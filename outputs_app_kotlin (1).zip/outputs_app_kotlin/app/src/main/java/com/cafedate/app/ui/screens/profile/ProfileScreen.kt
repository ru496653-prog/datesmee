package com.cafedate.app.ui.screens.profile

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Person
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.cafedate.app.data.MysteryStatus
import com.cafedate.app.data.OutputType
import com.cafedate.app.data.PrivacyMode
import com.cafedate.app.state.AppViewModel
import com.cafedate.app.ui.components.PostCard

@Composable
fun ProfileScreen(
    viewModel: AppViewModel,
    padding: PaddingValues,
    onOpenPost: (String) -> Unit,
    onOpenMystery: (String) -> Unit,
) {
    val isDark by viewModel.isDarkTheme
    val privacyMode by viewModel.privacyMode
    val user = viewModel.currentUser.value
    val saved = viewModel.posts.filter { viewModel.savedPostIds.contains(it.id) }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)) {
                    Icon(
                        Icons.Filled.Person,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp).padding(12.dp),
                    )
                }
                Spacer(Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(user.displayName, fontSize = MaterialTheme.typography.titleLarge.fontSize, fontWeight = FontWeight.Bold)
                    Text(
                        privacyLabel(privacyMode),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    )
                }
                IconButton(onClick = { viewModel.toggleTheme() }) {
                    Icon(if (isDark) Icons.Filled.DarkMode else Icons.Filled.LightMode, contentDescription = "Toggle theme")
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                StatBox("Stories", "${viewModel.posts.count { it.type == OutputType.STORY }}", Modifier.weight(1f))
                StatBox("Mysteries solved", "${viewModel.posts.count { it.mysteryStatus == MysteryStatus.SOLVED }}", Modifier.weight(1f))
                StatBox("Saved", "${viewModel.savedPostIds.size}", Modifier.weight(1f))
            }
            Spacer(Modifier.height(24.dp))
            Text("Saved", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            if (saved.isEmpty()) {
                Text(
                    "Nothing saved yet.",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    modifier = Modifier.padding(vertical = 16.dp),
                )
            }
        }
        items(saved, key = { it.id }) { post ->
            PostCard(
                post = post,
                viewModel = viewModel,
                onClick = {
                    if (post.type == OutputType.MYSTERY) onOpenMystery(post.id) else onOpenPost(post.id)
                },
            )
        }
    }
}

@Composable
private fun StatBox(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            textAlign = TextAlign.Center,
        )
    }
}

private fun privacyLabel(mode: PrivacyMode): String = when (mode) {
    PrivacyMode.REAL_PROFILE -> "Showing real profile"
    PrivacyMode.PSEUDONYM -> "Posting as a pseudonym"
    PrivacyMode.ANONYMOUS_USERNAME -> "Posting anonymously"
    PrivacyMode.ANONYMOUS_NUMBER -> "Posting as an anonymous number"
    PrivacyMode.FULLY_ANONYMOUS -> "Posting completely anonymously"
}
