package com.cafedate.app.navigation

object Routes {
    const val WELCOME = "welcome"
    const val AGE_GATE = "age_gate"
    const val CITIZENSHIP = "citizenship"
    const val PRIVACY_MODE = "privacy_mode"
    const val INTERESTS = "interests"
    const val HOME = "home"
    const val CREATE = "create"
    const val POST_DETAIL = "post_detail/{postId}"
    const val MYSTERY_DETAIL = "mystery_detail/{postId}"

    fun postDetail(postId: String) = "post_detail/$postId"
    fun mysteryDetail(postId: String) = "mystery_detail/$postId"
}
