package com.cafedate.app.ui.screens.home

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cafedate.app.data.OutputPost
import com.cafedate.app.data.OutputType
import com.cafedate.app.data.categoryOrder
import com.cafedate.app.state.AppViewModel
import com.cafedate.app.ui.components.PostCard

@Composable
fun FeedTab(
    viewModel: AppViewModel,
    padding: PaddingValues,
    onOpenPost: (String) -> Unit,
    onOpenMystery: (String) -> Unit,
) {
    var category by remember { mutableStateOf("For You") }
    val posts = if (category == "For You") {
        viewModel.visiblePosts
    } else {
        viewModel.visiblePosts.filter { matchesCategory(it, category) }
    }

    Column(modifier = Modifier.fillMaxSize().padding(padding)) {
        Row(modifier = Modifier.padding(16.dp, 12.dp, 16.dp, 0.dp)) {
            Text("OUTPUTS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
        }
        LazyRow(modifier = Modifier.padding(vertical = 10.dp)) {
            items(categoryOrder) { c ->
                FilterChip(
                    selected = c == category,
                    onClick = { category = c },
                    label = { Text(c) },
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }
        }
        LazyColumn(modifier = Modifier.padding(horizontal = 16.dp)) {
            items(posts, key = { it.id }) { post ->
                PostCard(
                    post = post,
                    viewModel = viewModel,
                    onClick = {
                        if (post.type == OutputType.MYSTERY) onOpenMystery(post.id) else onOpenPost(post.id)
                    },
                )
            }
        }
    }
}

fun matchesCategory(post: OutputPost, category: String): Boolean = when (category) {
    "Mysteries" -> post.type == OutputType.MYSTERY
    "Real Incidents" -> post.type == OutputType.REAL_INCIDENT
    "Stories" -> post.type == OutputType.STORY
    "Opinions" -> post.type == OutputType.OPINION
    "Questions" -> post.type == OutputType.QUESTION
    else -> true
}
