package com.cafedate.app.ui.screens.post

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.TextDecrease
import androidx.compose.material.icons.outlined.TextIncrease
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cafedate.app.data.Comment
import com.cafedate.app.data.OutputPost
import com.cafedate.app.state.AppViewModel
import com.cafedate.app.ui.components.CategoryChip
import kotlin.math.ceil

/** Distraction-light "Reading Mode" view for stories, opinions, and questions. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostDetailScreen(post: OutputPost, viewModel: AppViewModel, onBack: () -> Unit) {
    var fontSize by remember { mutableStateOf(17f) }
    var commentText by remember { mutableStateOf("") }
    val saved = viewModel.savedPostIds.contains(post.id)
    val readMinutes = ceil(post.body.split(" ").size / 200.0).toInt().coerceAtLeast(1)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {},
                actions = {
                    IconButton(onClick = { fontSize = (fontSize - 1).coerceIn(13f, 26f) }) {
                        Icon(Icons.Outlined.TextDecrease, contentDescription = "Decrease text size")
                    }
                    IconButton(onClick = { fontSize = (fontSize + 1).coerceIn(13f, 26f) }) {
                        Icon(Icons.Outlined.TextIncrease, contentDescription = "Increase text size")
                    }
                    IconButton(onClick = { viewModel.toggleSave(post.id) }) {
                        Icon(if (saved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder, contentDescription = "Save")
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)) {
            item {
                CategoryChip(label = post.category)
                Spacer(Modifier.height(12.dp))
                Text(post.title, fontSize = (fontSize + 8).sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "${post.authorLabel} · ~$readMinutes min read",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    fontSize = 12.sp,
                )
                Spacer(Modifier.height(20.dp))
                Text(post.body, fontSize = fontSize.sp, lineHeight = (fontSize * 1.6).sp)
                Spacer(Modifier.height(28.dp))
                HorizontalDivider()
                Spacer(Modifier.height(12.dp))
                Text("Comments (${post.comments.size})", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
            }
            items(post.comments, key = { it.id }) { comment ->
                Column(modifier = Modifier.padding(bottom = 14.dp)) {
                    Text(comment.author, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Spacer(Modifier.height(2.dp))
                    Text(comment.content)
                }
            }
            item {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = commentText,
                        onValueChange = { commentText = it },
                        placeholder = { Text("Add a comment…") },
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = {
                        val text = commentText.trim()
                        if (text.isNotEmpty()) {
                            viewModel.addComment(post.id, Comment(author = "You", content = text))
                            commentText = ""
                        }
                    }) {
                        Icon(Icons.Filled.Send, contentDescription = "Send")
                    }
                }
                Spacer(Modifier.height(40.dp))
            }
        }
    }
}
