package com.cafedate.app.data

import java.util.UUID

enum class PrivacyMode { REAL_PROFILE, PSEUDONYM, ANONYMOUS_USERNAME, ANONYMOUS_NUMBER, FULLY_ANONYMOUS }

enum class OutputType { STORY, OPINION, QUESTION, MYSTERY, REAL_INCIDENT, INVESTIGATION, EXPERIENCE, THEORY, ANNOUNCEMENT }

enum class MysteryStatus(val label: String) {
    OPEN("Open"),
    INVESTIGATING("Investigating"),
    STRONG_THEORY("Strong Theory"),
    SOLVED("Solved"),
    DEBUNKED("Debunked"),
    UNRESOLVED("Unresolved"),
}

data class AppUser(
    val id: String = "local-user",
    var displayName: String = "ShadowWriter",
    var bio: String? = null,
    var privacyMode: PrivacyMode = PrivacyMode.PSEUDONYM,
    var ageVerified: Boolean = false,
    var interests: List<String> = emptyList(),
) {
    /** The name shown publicly, respecting the chosen privacy mode. */
    fun publicName(anonNumber: Int): String = when (privacyMode) {
        PrivacyMode.REAL_PROFILE -> displayName
        PrivacyMode.PSEUDONYM -> displayName
        PrivacyMode.ANONYMOUS_USERNAME -> "Anon$displayName"
        PrivacyMode.ANONYMOUS_NUMBER -> "Anonymous #$anonNumber"
        PrivacyMode.FULLY_ANONYMOUS -> "Anonymous"
    }
}

data class Evidence(
    val id: String = UUID.randomUUID().toString(),
    val description: String,
    val contributor: String,
    val type: String, // photo, video, audio, document, link, testimony
    val confidence: String, // low, medium, high
)

data class Theory(
    val id: String = UUID.randomUUID().toString(),
    val author: String,
    val content: String,
    var supportCount: Int = 0,
    var challengeCount: Int = 0,
    var status: String = "interesting",
)

data class TimelineEvent(
    val time: String,
    val description: String,
)

data class Comment(
    val id: String = UUID.randomUUID().toString(),
    val author: String,
    val content: String,
    var reactions: Int = 0,
)

data class OutputPost(
    val id: String = UUID.randomUUID().toString(),
    val type: OutputType,
    val title: String,
    val body: String,
    val authorLabel: String,
    val category: String,
    val tags: List<String> = emptyList(),
    val createdAtMillis: Long = System.currentTimeMillis(),
    var saves: Int = 0,
    var commentCount: Int = 0,
    var reactionCount: Int = 0,
    var sensitive: Boolean = false,
    var mysteryStatus: MysteryStatus? = null,
    val evidence: MutableList<Evidence> = mutableListOf(),
    val theories: MutableList<Theory> = mutableListOf(),
    val timeline: MutableList<TimelineEvent> = mutableListOf(),
    val comments: MutableList<Comment> = mutableListOf(),
)
