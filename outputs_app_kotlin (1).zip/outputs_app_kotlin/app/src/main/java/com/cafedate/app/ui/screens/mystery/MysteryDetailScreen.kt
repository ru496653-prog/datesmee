package com.cafedate.app.ui.screens.mystery

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.RecordVoiceOver
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cafedate.app.data.OutputPost
import com.cafedate.app.data.Theory
import com.cafedate.app.state.AppViewModel
import com.cafedate.app.ui.components.CategoryChip

@Composable
fun MysteryDetailScreen(post: OutputPost, viewModel: AppViewModel, onBack: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    val titles = listOf("Overview", "Timeline", "Evidence", "Theories")

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(post.title, maxLines = 1) })
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                titles.forEachIndexed { index, title ->
                    Tab(selected = tab == index, onClick = { tab = index }, text = { Text(title) })
                }
            }
            when (tab) {
                0 -> OverviewTab(post)
                1 -> TimelineTab(post)
                2 -> EvidenceTab(post)
                3 -> TheoriesTab(post, viewModel)
            }
        }
    }
}

@Composable
private fun OverviewTab(post: OutputPost) {
    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Row {
            CategoryChip(label = post.category)
            Spacer(Modifier.width(8.dp))
            post.mysteryStatus?.let { AssistChip(onClick = {}, label = { Text(it.label) }) }
        }
        Spacer(Modifier.height(16.dp))
        Text(post.body, fontSize = 16.sp, lineHeight = 26.sp)
        Spacer(Modifier.height(20.dp))
        Text(
            "Posted by ${post.authorLabel}",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            fontSize = 12.sp,
        )
    }
}

@Composable
private fun TimelineTab(post: OutputPost) {
    if (post.timeline.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No timeline events yet.")
        }
        return
    }
    LazyColumn(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        items(post.timeline) { event ->
            Row(modifier = Modifier.padding(bottom = 18.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(MaterialTheme.colorScheme.primary, CircleShape),
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(event.time, fontWeight = FontWeight.Bold)
                    Text(event.description)
                }
            }
        }
    }
}

@Composable
private fun EvidenceTab(post: OutputPost) {
    if (post.evidence.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No evidence submitted yet.")
        }
        return
    }
    LazyColumn(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        items(post.evidence) { evidence ->
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                ListItem(
                    leadingContent = { Icon(iconForEvidence(evidence.type), contentDescription = null) },
                    headlineContent = { Text(evidence.description) },
                    supportingContent = { Text("${evidence.contributor} · confidence: ${evidence.confidence}") },
                )
            }
        }
    }
}

private fun iconForEvidence(type: String) = when (type) {
    "photo" -> Icons.Outlined.Image
    "video" -> Icons.Outlined.Videocam
    "audio" -> Icons.Outlined.Mic
    "testimony" -> Icons.Outlined.RecordVoiceOver
    else -> Icons.Outlined.Description
}

@Composable
private fun TheoriesTab(post: OutputPost, viewModel: AppViewModel) {
    var text by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        if (post.theories.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No theories yet — be the first.")
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f).padding(20.dp)) {
                items(post.theories) { theory ->
                    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(theory.author, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(theory.content)
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AssistChip(onClick = {}, label = { Text(theory.status) })
                                Spacer(Modifier.weight(1f))
                                Icon(Icons.Outlined.ThumbUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("${theory.supportCount}", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            }
                        }
                    }
                }
            }
        }
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Submit a theory…") },
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = {
                val trimmed = text.trim()
                if (trimmed.isNotEmpty()) {
                    viewModel.addTheory(post.id, Theory(author = "You", content = trimmed))
                    text = ""
                }
            }) {
                Icon(Icons.Filled.Send, contentDescription = "Submit theory")
            }
        }
    }
}
