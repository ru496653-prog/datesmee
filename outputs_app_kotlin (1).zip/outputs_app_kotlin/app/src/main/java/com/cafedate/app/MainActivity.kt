package com.cafedate.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.cafedate.app.navigation.OutputsNavGraph
import com.cafedate.app.state.AppViewModel
import com.cafedate.app.ui.theme.OutputsTheme

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val isDark by viewModel.isDarkTheme
            OutputsTheme(darkTheme = isDark) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    OutputsNavGraph(viewModel = viewModel)
                }
            }
        }
    }
}
