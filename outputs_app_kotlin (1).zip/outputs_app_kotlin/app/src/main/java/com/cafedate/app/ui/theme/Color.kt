package com.cafedate.app.ui.theme

import androidx.compose.ui.graphics.Color

val Purple = Color(0xFF7C5CFF)
val Charcoal = Color(0xFF15151B)
val Surface = Color(0xFF1E1E26)
val Cream = Color(0xFFF5EFE3)

val CategoryRed = Color(0xFFE05A5A)
val CategoryBlue = Color(0xFF4FA3E3)
val CategoryYellow = Color(0xFFE3B84F)
val CategoryGreen = Color(0xFF4FE3A0)

fun categoryColor(category: String): Color = when (category) {
    "Mystery" -> Purple
    "Real Incident" -> CategoryRed
    "Opinion" -> CategoryBlue
    "Question" -> CategoryYellow
    "Story" -> CategoryGreen
    else -> Purple
}
