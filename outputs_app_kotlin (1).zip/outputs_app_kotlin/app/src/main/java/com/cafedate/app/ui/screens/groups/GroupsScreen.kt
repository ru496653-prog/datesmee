package com.cafedate.app.ui.screens.groups

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class Group(val name: String, val description: String, val members: Int, val privacy: String)

private val groups = listOf(
    Group("Midnight Investigators", "Late-night mystery solving and evidence review.", 1240, "Public"),
    Group("Kathmandu Mystery Group", "Local unexplained incidents around the valley.", 380, "Private"),
    Group("Archive Keepers", "Cataloguing solved and unsolved historical cases.", 96, "Anonymous"),
)

@Composable
fun GroupsScreen(padding: PaddingValues) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
        item {
            Row(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                Text("Groups", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f, fill = true))
                TextButton(onClick = { /* group creation flow */ }) { Text("+ New") }
            }
        }
        items(groups) { group ->
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text(
                    group.name,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 12.dp, start = 16.dp, end = 16.dp),
                )
                Text(
                    group.description,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                Text(
                    "${group.members} members · ${group.privacy}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
                )
            }
        }
    }
}
