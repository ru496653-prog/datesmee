package com.cafedate.app.ui.screens.explore

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cafedate.app.data.OutputType
import com.cafedate.app.state.AppViewModel
import com.cafedate.app.ui.components.PostCard

@Composable
fun ExploreScreen(
    viewModel: AppViewModel,
    padding: PaddingValues,
    onOpenPost: (String) -> Unit,
    onOpenMystery: (String) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val q = query.trim().lowercase()
    val results = if (q.isEmpty()) {
        viewModel.visiblePosts
    } else {
        viewModel.visiblePosts.filter {
            it.title.lowercase().contains(q) ||
                it.category.lowercase().contains(q) ||
                it.tags.any { tag -> tag.lowercase().contains(q) }
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(padding)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            placeholder = { Text("Search posts, mysteries, tags, groups…") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
        )
        if (results.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
                Text("No results.")
            }
        } else {
            LazyColumn(modifier = Modifier.padding(horizontal = 16.dp)) {
                items(results, key = { it.id }) { post ->
                    PostCard(
                        post = post,
                        viewModel = viewModel,
                        onClick = {
                            if (post.type == OutputType.MYSTERY) onOpenMystery(post.id) else onOpenPost(post.id)
                        },
                    )
                }
            }
        }
    }
}
