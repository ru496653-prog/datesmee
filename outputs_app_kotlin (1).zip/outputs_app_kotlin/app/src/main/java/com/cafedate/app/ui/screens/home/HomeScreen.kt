package com.cafedate.app.ui.screens.home

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.MailOutline
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.cafedate.app.state.AppViewModel
import com.cafedate.app.ui.screens.explore.ExploreScreen
import com.cafedate.app.ui.screens.groups.GroupsScreen
import com.cafedate.app.ui.screens.inbox.InboxScreen
import com.cafedate.app.ui.screens.profile.ProfileScreen

@Composable
fun HomeScreen(
    viewModel: AppViewModel,
    onOpenPost: (String) -> Unit,
    onOpenMystery: (String) -> Unit,
    onCreate: () -> Unit,
) {
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Home", "Explore", "Groups", "Inbox", "Profile")
    val icons = listOf(Icons.Filled.Home, Icons.Outlined.Explore, Icons.Outlined.Groups, Icons.Outlined.MailOutline, Icons.Outlined.Person)

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onCreate) {
                Icon(Icons.Filled.Add, contentDescription = "Create Output")
            }
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(icons[index], contentDescription = label) },
                        label = { Text(label) },
                    )
                }
            }
        },
    ) { padding ->
        when (tab) {
            0 -> FeedTab(viewModel = viewModel, padding = padding, onOpenPost = onOpenPost, onOpenMystery = onOpenMystery)
            1 -> ExploreScreen(viewModel = viewModel, padding = padding, onOpenPost = onOpenPost, onOpenMystery = onOpenMystery)
            2 -> GroupsScreen(padding = padding)
            3 -> InboxScreen(padding = padding)
            4 -> ProfileScreen(viewModel = viewModel, padding = padding, onOpenPost = onOpenPost, onOpenMystery = onOpenMystery)
        }
    }
}
