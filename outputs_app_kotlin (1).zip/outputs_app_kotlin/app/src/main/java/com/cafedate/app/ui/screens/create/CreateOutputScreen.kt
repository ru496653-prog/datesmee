package com.cafedate.app.ui.screens.create

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenu
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cafedate.app.data.MysteryStatus
import com.cafedate.app.data.OutputPost
import com.cafedate.app.data.OutputType
import com.cafedate.app.data.PrivacyMode
import com.cafedate.app.state.AppViewModel

private val typeOptions = listOf(
    OutputType.STORY to "Story",
    OutputType.OPINION to "Opinion",
    OutputType.QUESTION to "Question",
    OutputType.MYSTERY to "Mystery",
    OutputType.REAL_INCIDENT to "Real Incident",
    OutputType.INVESTIGATION to "Investigation",
)

private val identityOptions = listOf(
    PrivacyMode.REAL_PROFILE to "My profile",
    PrivacyMode.PSEUDONYM to "Pseudonym",
    PrivacyMode.ANONYMOUS_NUMBER to "Anonymous #XXXX",
    PrivacyMode.FULLY_ANONYMOUS to "Completely anonymous",
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CreateOutputScreen(viewModel: AppViewModel, onDone: () -> Unit) {
    var type by remember { mutableStateOf<OutputType?>(null) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var identity by remember { mutableStateOf(viewModel.privacyMode.value) }
    var identityMenuOpen by remember { mutableStateOf(false) }

    val canPost = type != null && title.trim().isNotEmpty()

    Scaffold(topBar = { TopAppBar(title = { Text("Create Output") }) }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            Text("What are you posting?", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            FlowRow {
                typeOptions.forEach { (value, label) ->
                    FilterChip(
                        selected = type == value,
                        onClick = { type = value },
                        label = { Text(label) },
                        modifier = Modifier.padding(4.dp),
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = body,
                onValueChange = { body = it },
                label = { Text("Your story") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
            )
            Spacer(Modifier.height(12.dp))
            FlowRow {
                listOf("Photo", "Video", "Voice", "Evidence", "Timeline").forEach {
                    AssistChip(onClick = {}, label = { Text(it) }, modifier = Modifier.padding(4.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            ExposedDropdownMenuBox(expanded = identityMenuOpen, onExpandedChange = { identityMenuOpen = it }) {
                OutlinedTextField(
                    value = identityOptions.first { it.first == identity }.second,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Identity") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = identityMenuOpen) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor(),
                )
                ExposedDropdownMenu(expanded = identityMenuOpen, onDismissRequest = { identityMenuOpen = false }) {
                    identityOptions.forEach { (value, label) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = {
                            identity = value
                            identityMenuOpen = false
                        })
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "Make sure your post doesn't expose someone else's private information or put anyone at risk.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            )
            Spacer(Modifier.height(12.dp))
            Row {
                OutlinedButton(
                    onClick = { /* draft saving would persist locally/remotely */ },
                    enabled = canPost,
                    modifier = Modifier.weight(1f),
                ) { Text("Save draft") }
                Spacer(Modifier.width(12.dp))
                Button(
                    onClick = {
                        val category = categoryFor(type!!)
                        viewModel.addPost(
                            OutputPost(
                                type = type!!,
                                title = title.trim(),
                                body = body.trim().ifEmpty { "No description provided." },
                                authorLabel = viewModel.currentUser.value.publicName(9000 + viewModel.posts.size),
                                category = category,
                                mysteryStatus = if (type == OutputType.MYSTERY) MysteryStatus.OPEN else null,
                            ),
                        )
                        onDone()
                    },
                    enabled = canPost,
                    modifier = Modifier.weight(1f),
                ) { Text("Post") }
            }
        }
    }
}

private fun categoryFor(type: OutputType): String = when (type) {
    OutputType.STORY -> "Story"
    OutputType.OPINION -> "Opinion"
    OutputType.QUESTION -> "Question"
    OutputType.MYSTERY -> "Mystery"
    OutputType.REAL_INCIDENT -> "Real Incident"
    else -> "Investigation"
}
