package com.cafedate.app.data

/**
 * In-memory sample content so every screen renders something real.
 * Swap this out for a real backend (Firebase/Supabase) later — see README.md
 * for suggested wiring points.
 */
fun buildMockPosts(): MutableList<OutputPost> = mutableListOf(
    OutputPost(
        id = "p1",
        type = OutputType.MYSTERY,
        title = "The Lights That Appeared Every Night",
        body = "For six weeks straight, a set of lights appeared over the ridge behind our village at almost " +
            "exactly 10:30 PM. No one could explain where they came from, and they stopped as suddenly as they started.",
        authorLabel = "Anonymous #4821",
        category = "Mystery",
        tags = listOf("#Unexplained", "#Kathmandu"),
        saves = 128,
        commentCount = 42,
        reactionCount = 310,
        mysteryStatus = MysteryStatus.INVESTIGATING,
        evidence = mutableListOf(
            Evidence(id = "e1", description = "Photo of the lights from the rooftop, 10:34 PM", contributor = "Anonymous #4821", type = "photo", confidence = "medium"),
            Evidence(id = "e2", description = "Neighbor testimony describing a low humming sound", contributor = "Anonymous #91", type = "testimony", confidence = "low"),
        ),
        theories = mutableListOf(
            Theory(id = "t1", author = "Anonymous #12", content = "Could be light reflecting off fog from a vehicle on the ridge road.", supportCount = 34, status = "supported"),
            Theory(id = "t2", author = "ShadowWriter", content = "Possible drone testing from the nearby facility.", supportCount = 19, status = "interesting"),
        ),
        timeline = mutableListOf(
            TimelineEvent(time = "10:30 PM", description = "Lights first observed on the ridge"),
            TimelineEvent(time = "10:42 PM", description = "Unknown low humming sound reported by neighbors"),
            TimelineEvent(time = "11:03 PM", description = "Lights fade out gradually"),
        ),
        comments = mutableListOf(
            Comment(id = "c1", author = "NightOwl22", content = "Same thing happened near my place last year.", reactions = 12),
        ),
    ),
    OutputPost(
        id = "p2",
        type = OutputType.REAL_INCIDENT,
        title = "Found an abandoned shop that closed overnight",
        body = "The tea shop on our street had customers the night before, and by morning the shutters were down " +
            "with no notice. The owner isn't answering calls. Has anyone seen them since?",
        authorLabel = "Anonymous #7294",
        category = "Real Incident",
        tags = listOf("#RealIncident"),
        saves = 54,
        commentCount = 21,
        reactionCount = 88,
    ),
    OutputPost(
        id = "p3",
        type = OutputType.OPINION,
        title = "Anonymous platforms make people more honest, not less",
        body = "People assume anonymity brings out the worst in a community. In my experience running forums " +
            "for a decade, the opposite happens when moderation is strong — people share things they'd never say " +
            "under their real name, and most of it is useful, not toxic.",
        authorLabel = "ShadowWriter",
        category = "Opinion",
        tags = listOf("#Opinion", "#Community"),
        saves = 40,
        commentCount = 65,
        reactionCount = 210,
    ),
    OutputPost(
        id = "p4",
        type = OutputType.QUESTION,
        title = "Has anyone else heard footsteps on an empty top floor?",
        body = "We rent the ground floor of an old building. Every night around 2 AM there are footsteps upstairs, " +
            "but the top floor has been empty for a year.",
        authorLabel = "Anonymous",
        category = "Question",
        tags = listOf("#Unexplained"),
        saves = 22,
        commentCount = 33,
        reactionCount = 71,
    ),
    OutputPost(
        id = "p5",
        type = OutputType.STORY,
        title = "The Last Bus of Winter",
        body = "It was the last bus out of the valley before the snow closed the pass, and the driver knew every " +
            "one of us by name — except for the man in the back seat none of us had seen before.",
        authorLabel = "ArchiveKeeper",
        category = "Story",
        tags = listOf("#Story", "#Fiction"),
        saves = 96,
        commentCount = 18,
        reactionCount = 240,
    ),
)

val categoryOrder = listOf("For You", "Mysteries", "Real Incidents", "Stories", "Opinions", "Questions")

val interestOptions = listOf(
    "Mystery", "Horror", "History", "Technology", "Stories", "Real Incidents", "Science", "Opinions",
)
