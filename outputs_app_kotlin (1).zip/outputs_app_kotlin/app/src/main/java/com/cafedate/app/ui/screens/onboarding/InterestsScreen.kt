package com.cafedate.app.ui.screens.onboarding

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cafedate.app.data.interestOptions
import com.cafedate.app.state.AppViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun InterestsScreen(viewModel: AppViewModel, onFinish: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Choose your interests") }) }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
        ) {
            FlowRow(modifier = Modifier.weight(1f)) {
                interestOptions.forEach { interest ->
                    val selected = viewModel.selectedInterests.contains(interest)
                    FilterChip(
                        selected = selected,
                        onClick = { viewModel.toggleInterest(interest) },
                        label = { Text(interest) },
                        modifier = Modifier.padding(4.dp),
                    )
                }
            }
            Button(onClick = onFinish, modifier = Modifier.fillMaxWidth()) {
                Text("You're ready", modifier = Modifier.padding(vertical = 6.dp))
            }
        }
    }
}
